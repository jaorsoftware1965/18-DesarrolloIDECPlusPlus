// Incluye la Librería
# include "stdio.h"

// Función main
int main()
{

   // Despliega un mensaje de Hola Mundo
   printf("Hola Mundo");
   
   // Retorna 0
   return 0;
}